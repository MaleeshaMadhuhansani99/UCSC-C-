#include <stdio.h> 
#include <string.h>
   
void main(){

   printf("Alphebet(lowercase letters):\n");
   for(char i=97;i<=122;i++){
      printf("%c\t",i);
         
   }
   printf("\n");
   printf("Alphebet(uppercase letters):\n ");
   for(char i=65;i<=90;i++){
      printf("%c\t",i);
   }
}

   

